﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace xNetStat
{
    internal class Ipv4TcpConnections
    {
       public static string GetIpv4TcpConnections() {
            //https://www.pinvoke.net/default.aspx/iphlpapi/GetExtendedTcpTable.html
            var PacketList = new List<Packet>();
            var dwNumEntriesField = typeof(IphlpapiStruct.MIB_TCPTABLE_OWNER_PID).GetField("dwNumEntries");
            int BuffLen = 0;

            //First Call get the size for the buffer.  We need to call this twice.
            uint response;
            response = IphlpapiFunctionCall.GetExtendedTcpTable(IntPtr.Zero, ref BuffLen, true, IpVersion.AF_INET, IphlpapiEnums.TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, 0);
            var TablePtr = Marshal.AllocHGlobal(BuffLen);

            //2nd Call. With our structure and buffer size.

            response = IphlpapiFunctionCall.GetExtendedTcpTable(TablePtr, ref BuffLen, true, IpVersion.AF_INET, IphlpapiEnums.TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, 0);
            
            //Converting to structure
            IphlpapiStruct.MIB_TCPTABLE_OWNER_PID TablStruct = (IphlpapiStruct.MIB_TCPTABLE_OWNER_PID)Marshal.PtrToStructure(TablePtr,typeof(IphlpapiStruct.MIB_TCPTABLE_OWNER_PID));
            int RowStructureSize = Marshal.SizeOf(typeof(IphlpapiStruct.MIB_TCPROW_OWNER_PID));
            //Array for holding the table. each row end of table + offset memory.
            IntPtr rArrayPtr = (IntPtr)((long)TablePtr + (long)Marshal.OffsetOf(typeof(IphlpapiStruct.MIB_TCPTABLE_OWNER_PID), "table"));

            for (int i = 0, loopto = (int)TablStruct.dwNumEntries; i <= loopto; i++) {
                var _Packet = new Packet();
                IphlpapiStruct.MIB_TCPROW_OWNER_PID TableRow = (IphlpapiStruct.MIB_TCPROW_OWNER_PID)Marshal.PtrToStructure(rArrayPtr, typeof(IphlpapiStruct.MIB_TCPROW_OWNER_PID));

                _Packet.LocalAddr = TableRow.LocalAddress.ToString();

                
                _Packet.LocalPort = TableRow.LocalPort;
                _Packet.RemoteAddr = TableRow.RemoteAddress.ToString();
                _Packet.RemotePort = TableRow.RemotePort;
                _Packet.PidID = TableRow.owningPid;
                _Packet.PidName = Tools._GetProcessNameById(TableRow.owningPid);

                bool b = _Packet.RemoteAddr.Contains("0");
                if (b == false) {

                    string myBreak = "";
                }

                //Add it to our list
                PacketList.Add(_Packet);

                //Next Entry in line
                rArrayPtr = (IntPtr)((long)rArrayPtr + RowStructureSize);
            
            
            }

            string jsonstring = Tools._ToJsonStr(PacketList);
            return jsonstring;

        }
    }
}

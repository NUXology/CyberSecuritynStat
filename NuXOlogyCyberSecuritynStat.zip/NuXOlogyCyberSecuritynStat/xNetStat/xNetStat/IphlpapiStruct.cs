﻿using System;
using System.Net;
using System.Runtime.InteropServices;

using static xNetStat.IphlpapiEnums;

namespace xNetStat
{
    internal class IphlpapiStruct
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct in_addr
        {
            public byte s_b1;
            public byte s_b2;
            public byte s_b3;
            public byte s_b4;
        }

        //https://learn.microsoft.com/en-us/windows/win32/api/tcpmib/ns-tcpmib-mib_tcprow_owner_pid
        //https://www.pinvoke.net/default.aspx/Structures/MIB_TCPTABLE_OWNER_PID.html
        [StructLayout(LayoutKind.Sequential)]
        public struct MIB_TCPTABLE_OWNER_PID
        {
            public uint dwNumEntries;
            [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.Struct, SizeConst = 1)]
            public MIB_TCPROW_OWNER_PID[] table;
        }
        //https://www.pinvoke.net/default.aspx/Structures/MIB_TCPROW_OWNER_PID.html
        [StructLayout(LayoutKind.Sequential)]
        public struct MIB_TCPROW_OWNER_PID
        {
            public uint m_state;
            public uint localAddr;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] m_localPort;
            public uint remoteAddr;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] m_remotePort;
            public uint owningPid;

            public uint ProcessId
            {
                get
                {
                    return owningPid;
                }
            }

            public IPAddress LocalAddress
            {
                get
                {
                    return new IPAddress(localAddr);
                }
            }

            public ushort LocalPort
            {
                get
                {
                    return BitConverter.ToUInt16(new byte[2] { m_localPort[1], m_localPort[0] }, 0);
                }
            }

            public IPAddress RemoteAddress
            {
                get
                {
                    return new IPAddress(remoteAddr);
                }
            }

            public ushort RemotePort
            {
                get
                {
                    return BitConverter.ToUInt16(new byte[2] { m_remotePort[1], m_remotePort[0] }, 0);
                }
            }

            public MIB_TCP_STATE State
            {
                get
                {
                    MIB_TCP_STATE StateRet = default;
                    return StateRet;
                }
            }
        }
    }
}

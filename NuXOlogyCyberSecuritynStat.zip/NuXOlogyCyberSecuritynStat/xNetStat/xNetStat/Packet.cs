﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xNetStat
{
    internal class Packet
    {
        public string LocalAddr { get; set; }
        public ushort LocalPort { get; set; }
        public string RemoteAddr { get; set; }
        public ushort RemotePort { get; set; }
        public UInt64 PidID { get; set; } //Process ID length depends on system resources. So nybble, bit, byte, etc would not be enough.  Go Big. UInt64 
        public string PidName { get; set; }
    }
}

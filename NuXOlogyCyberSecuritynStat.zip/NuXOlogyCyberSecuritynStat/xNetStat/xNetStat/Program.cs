﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xNetStat
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Hello
            //Console.WriteLine("hello world");
            Console.WriteLine(Ipv4TcpConnections.GetIpv4TcpConnections());
            string mybreak = "";
        }
    }
}

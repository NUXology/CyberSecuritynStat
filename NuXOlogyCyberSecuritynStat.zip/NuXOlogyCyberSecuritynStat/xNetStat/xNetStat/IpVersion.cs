﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xNetStat
{
    internal class IpVersion
    {
        public const int AF_INET = 2; // IPv4
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Text.Json;


namespace xNetStat
{
    internal class Tools
    {

        public static string _ToJsonStr(List<Packet> pckt) {
            //Install Package 'System.text.Json'

            //Serialize Packet to Json
            string JsonString;
            JsonString = JsonSerializer.Serialize(pckt);
            return JsonString;
        
        }

        public static string _GetProcessNameById(long pid) {
            Process proc;
            string ProcName = "";

            try
            {
                
                //Return the ProcessName
                proc = Process.GetProcessById((int)pid);
                ProcName = proc.ProcessName;
                return ProcName;
            }
            catch (ArgumentException e)
            {
                return ProcName;
            }
            catch (OverflowException e) { 
                return ProcName;
            } catch (Exception e)
            {
                return ProcName;
            }
        }


    }
}

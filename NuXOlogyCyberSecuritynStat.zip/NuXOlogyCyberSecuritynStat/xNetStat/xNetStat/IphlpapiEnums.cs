﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xNetStat
{
    internal class IphlpapiEnums
    {
        //https://learn.microsoft.com/en-us/windows/win32/api/iprtrmib/ne-iprtrmib-tcp_table_class
        public enum TCP_TABLE_CLASS
        {
            TCP_TABLE_BASIC_LISTENER = 0,
            TCP_TABLE_BASIC_CONNECTIONS = 1,
            TCP_TABLE_BASIC_ALL = 2,
            TCP_TABLE_OWNER_PID_LISTENER = 3,
            TCP_TABLE_OWNER_PID_CONNECTIONS = 4,
            TCP_TABLE_OWNER_PID_ALL = 5,
            TCP_TABLE_OWNER_MODULE_LISTENER = 6,
            TCP_TABLE_OWNER_MODULE_CONNECTIONS = 7,
            TCP_TABLE_OWNER_MODULE_ALL = 8
        }
        //https://learn.microsoft.com/en-us/windows/win32/api/tcpmib/ns-tcpmib-mib_tcprow_owner_pid
        public enum MIB_TCP_STATE
        {
            MIB_TCP_STATE_CLOSEDField = 1,
            MIB_TCP_STATE_LISTENField = 2,
            MIB_TCP_STATE_SYN_SENTField = 3,
            MIB_TCP_STATE_SYN_RCVDField = 4,
            MIB_TCP_STATE_ESTABField = 5,
            MIB_TCP_STATE_FIN_WAIT1Field = 6,
            MIB_TCP_STATE_FIN_WAIT2Field = 7,
            MIB_TCP_STATE_CLOSE_WAITField = 8,
            MIB_TCP_STATE_CLOSINGField = 9,
            MIB_TCP_STATE_LAST_ACKField = 10,
            MIB_TCP_STATE_TIME_WAITField = 11,
            MIB_TCP_STATE_DELETE_TCBField = 12
        }

    }
}

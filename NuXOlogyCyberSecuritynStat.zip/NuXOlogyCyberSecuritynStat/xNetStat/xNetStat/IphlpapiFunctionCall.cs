﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static xNetStat.IphlpapiEnums;

namespace xNetStat
{
    internal class IphlpapiFunctionCall
    {
        //public const int AF_INET = 2; // IPv4 -> moved
        [DllImport("iphlpapi.dll", SetLastError = true)]
        public static extern uint GetExtendedTcpTable(IntPtr pTcpTable, ref int dwOutBufLen, bool sort, int ipVersion, TCP_TABLE_CLASS tblClass, int reserved);
    }
}
